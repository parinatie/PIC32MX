#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/attribs.h>
/*Function to produce delay
 * parameter: uint16_t ms: delay in msec
 * return: void
 */
void delay(uint16_t ms)
{
    uint16_t i=0,j=0;
    for(i=0; i<=ms;i++)
        for(j=0;j<=8888;j++);
}

/* Initialize Interrupt 1 
 * parameter: void
 * return: void
 */
void Int1_init(void)
{
    //INT1 initialization
    INTCONSET=_INTCON_MVEC_MASK | _INTCON_INT1EP_MASK; // Multi vector mode, Rising edge
    IFS0CLR=_IFS0_INT1IF_MASK; // clear INT1 flag
    IPC1bits.INT1IP=0x07; // Group priority 7
    IPC1bits.INT1IS=0x03; // Subpriority 3
    IEC0SET=_IEC0_INT1IE_MASK; // Enable INT1    
} 
