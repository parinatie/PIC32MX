/* 
 * File:   LEDBlinkMain.c
 * Author: prabr
 *
 * Created on 19 March, 2020, 5:22 PM
 */
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/attribs.h>
#include "lcd_library.h"
#include "PPLib.h"
/*
 * This program blinks LED1 and LED2
 * using Switches SW1 and SW3
 * PIC32MX795F512L
 */
volatile uint8_t SW3_status=0;
int main(int argc, char** argv) 
{
    uint8_t i=0;
    SW1_DI(); //RD13-SW1 as input
    SW3_DI(); //RE8- SW3 as input
    LED1_DO(); LED2_DO(); LED3_DO(); LED4_DO();
    LED1_OFF(); LED2_ON(); LED3_ON(); LED4_OFF();  
    
    Int1_init();// Initilaizes INT1
    __builtin_enable_interrupts();//Enable global Interrupt
    
    lcd_init();
    clear_display();
    lcd_display("   Parinatie    PIC32 Dev. Board");
    while(1)
    {
        if(SW1_PRESSED()) // if SW1 is pressed
        {
            LED1_TOGGLE();
        }
        else // switch not pressed
        {
            LED2_TOGGLE();
        }
        
        if(SW3_status) 
        {
            LED3_TOGGLE();
        }
        else
        {
            LED4_TOGGLE();
        }
    
        //delay(1000); // 1sec delay
        for(i=0;i<3;i++)
        {
            LCD_Lshift();
            delay(200);
        }
        for(i=0;i<3;i++)
        {
            LCD_Rshift();
            delay(200);
        }
    }
    return (EXIT_SUCCESS);
}

//ISR
void __ISR(_EXTERNAL_1_VECTOR, IPL7SOFT) ExtInt1_isr(void)
{
    IFS0CLR=_IFS0_INT1IF_MASK; //clear INT1 flag
    //LED3_TOGGLE();
    SW3_status=~SW3_status;
    delay(100);    
}

