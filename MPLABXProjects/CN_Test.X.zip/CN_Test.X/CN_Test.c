/* 
 * File:   LEDBlinkMain.c
 * Author: prabr
 *
 * Created on 19 March, 2020, 5:22 PM
 */
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/attribs.h>
#include "lcd_library.h"
#include "PPLib.h"
/*
 * This program blinks LED1 and LED2
 * using Switches SW1 and SW3
 * PIC32MX795F512L
 */
volatile uint8_t SW1_status=0,SW2_status=0, SW3_status=0, SW4_status=0;
int main(int argc, char** argv) 
{
    uint8_t i=0;
    SW1_DI(); //RD13-SW1 as input
    SW3_DI(); //RE8- SW3 as input
    LED1_DO(); LED2_DO(); LED3_DO(); LED4_DO();
    LED1_OFF(); LED2_OFF(); LED3_OFF(); LED4_OFF();  
    
    Int1_init();// Initilaizes INT1
    CN19_Init(); // Initializes CN19-RD13- no internal pullup 
    CN2_Init();
    CN3_Init();
    __builtin_enable_interrupts();//Enable global Interrupt
    
    lcd_init();
    clear_display();
    lcd_display("   Parinatie    PIC32 Dev. Board");
    while(1)
    {
        if(SW1_status) // if SW1 is pressed
        {
            LED1_TOGGLE();
        }
        if(SW2_status)
        {
            LED2_TOGGLE();
        }        
        if(SW3_status) 
        {
            LED3_TOGGLE();
        }
        if(SW4_status)
        {
            LED4_TOGGLE();
        }    
        delay(500); // 0.5sec delay
        clear_display();
        
    }
    return (EXIT_SUCCESS);
}

//ISR
void __ISR(_EXTERNAL_1_VECTOR, IPL7SOFT) ExtInt1_isr(void)
{
    IFS0CLR=_IFS0_INT1IF_MASK; //clear INT1 flag
    //LED3_TOGGLE();
    SW3_status=~SW3_status;
    clear_display();
    lcd_display("   Parinatie      SW3 Pressed");
    delay(100);    
}

void __ISR(_CHANGE_NOTICE_VECTOR, IPL7SOFT) CNINT_isr(void)
{
    IFS1CLR=_IFS1_CNIF_MASK; //clear INT1 flag 
    clear_display();
    if(SW1_PRESSED()) //To identify which Switch caused CN Event- clears mismatch condition
    {
        SW1_status=~SW1_status;        
        lcd_display("   Parinatie      SW1 Pressed");
    }
    if(SW2_PRESSED()) //To identify which Switch caused CN Event- clears mismatch condition
    {
        SW2_status=~SW2_status;        
        lcd_display("   Parinatie      SW2 Pressed");
    }
    if(SW4_PRESSED()) //To identify which Switch caused CN Event- clears mismatch condition
    {
        SW4_status=~SW4_status;        
        lcd_display("   Parinatie      SW4 Pressed");
    }
    delay(100);    
}