/* 
 * File:   LEDBlinkMain.c
 * Author: prabr
 *
 * Created on 19 March, 2020, 5:22 PM
 */
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

#define LED1_DO()       (TRISDCLR=_TRISD_TRISD0_MASK)
#define LED1_ON()       (LATDSET=_LATD_LATD0_MASK)
#define LED1_OFF()      (LATDCLR=_LATD_LATD0_MASK)
#define LED1_TOGGLE()   (LATDINV=_LATD_LATD0_MASK)

#define LED2_DO()       (TRISDCLR=_TRISD_TRISD1_MASK)
#define LED2_ON()       (LATDSET=_LATD_LATD1_MASK)
#define LED2_OFF()      (LATDCLR=_LATD_LATD1_MASK)
#define LED2_TOGGLE()   (LATDINV=_LATD_LATD1_MASK)

#define LED3_DO()       (TRISDCLR=_TRISD_TRISD2_MASK)
#define LED3_ON()       (LATDSET=_LATD_LATD2_MASK)
#define LED3_OFF()      (LATDCLR=_LATD_LATD2_MASK)
#define LED3_TOGGLE()   (LATDINV=_LATD_LATD2_MASK)

#define LED4_DO()       (TRISGCLR=_TRISG_TRISG15_MASK)
#define LED4_ON()       (LATGSET=_LATG_LATG15_MASK)
#define LED4_OFF()      (LATGCLR=_LATG_LATG15_MASK)
#define LED4_TOGGLE()   (LATGINV=_LATG_LATG15_MASK)


/*Function to produce delay
 * parameter: uint16_t ms: delay in msec
 * return: void
 */
void delay(uint16_t ms)
{
    uint16_t i=0,j=0;
    for(i=0; i<=ms;i++)
        for(j=0;j<=8888;j++);
}
//void LED1_ON(void){PORTDSET=_PORTD_RD0_MASK;}
/*
 * This program blink LED1 and LED2
 * PIC32MX795F512L
 */
int main(int argc, char** argv) 
{
    LED1_DO(); LED2_DO(); LED3_DO(); LED4_DO();
    LED1_OFF(); LED2_ON(); LED3_ON(); LED4_OFF();

    while(1)
    {
        LED1_TOGGLE();
        LED2_TOGGLE();
        LED3_TOGGLE();
        LED4_TOGGLE();      
        delay(1000); // 1sec delay
    }
    return (EXIT_SUCCESS);
}

