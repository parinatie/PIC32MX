/* 
 * File:   LEDBlinkMain.c
 * Author: prabr
 *
 * Created on 22 March, 2020, 10:39 AM
 */

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

/* delayms provides delay
 * @params: uint16_t ms: delay in msec
 * return-void
 * 
 */
void delayms(uint16_t ms)
{
    uint16_t i=0,j=0;
    for(i=0;i<=ms;i++)
    {
        for(j=0;j<=8888;j++); //1 msec delay
    }
}
int main(int argc, char** argv) 
{
    TRISDCLR=_TRISD_TRISD0_MASK|_TRISD_TRISD1_MASK;    
   // TRISDbits.TRISD0=0; // LED1- RD0 as output
    //TRISDbits.TRISD1=0; // LED2- RD1 as output
    //TRISD=0x00; // PORTD is output - affects other port pins
    
    LATDCLR=_LATD_LATD0_MASK;
    LATDSET=_LATD_LATD1_MASK;
   // LATDbits.LATD0=0; // LED1 OFF
   // LATDbits.LATD1=1; // LED2 ON
    
    
    //PORTD=0x0002; // no control over individual pin
    //LATD &=~((1<<0)|(1<<1)|(1<<2)); // RD0, RD1, RD2 becomes 0
    //LATD|=(1<<1)|(1<<2)|(1<<3); // RD1, RD2, RD3 becomes 1
    while(1)
    {
        //LATDbits.LATD0=~(LATDbits.LATD0); // toggle RD0
        LATDINV=_LATD_LATD0_MASK;// 0x0001; // RD0 to toggle
        delayms(1000); // 1sec delay--user defined delay routine
        //LATDbits.LATD1=~(LATDbits.LATD1); //toggle RD1
        LATDINV=_LATD_LATD1_MASK;// 0x0002;
        delayms(1000);
    }
    return (EXIT_SUCCESS);
}

