/* 
 * File:   LEDBlinkMain.c
 * Author: prabr
 *
 * Created on 19 March, 2020, 5:22 PM
 */
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

/*Function to produce delay
 * parameter: uint16_t ms: delay in msec
 * return: void
 */
void delay(uint16_t ms)
{
    uint16_t i=0,j=0;
    for(i=0; i<=ms;i++)
        for(j=0;j<=8888;j++);
}
//void LED1_ON(void){PORTDSET=_PORTD_RD0_MASK;}
/*
 * This program blink LED1 and LED2
 * PIC32MX795F512L
 */
int main(int argc, char** argv) 
{
    TRISDbits.TRISD0=0; // LED1- connected to RD0
    TRISDbits.TRISD1=0; // LED2- connected to RD1
    LATDbits.LATD0=0; // LED1- is OFF
    LATDbits.LATD1=1; // LED2- is ON

    while(1)
    {
        //PORTDbits.RD0=~(PORTDbits.RD0); // toggle LED1 read-modify-write issue
        PORTDINV=_PORTD_RD0_MASK; // 0x0001 invert RD0        
        delay(1000); // 1sec delay
        //PORTDbits.RD1=~(PORTDbits.RD1); // toggle LED2 
        PORTDINV=_PORTD_RD1_MASK; // 0x0002 invert RD1        
        delay(1000); // 1sec delay
    }
    return (EXIT_SUCCESS);
}

