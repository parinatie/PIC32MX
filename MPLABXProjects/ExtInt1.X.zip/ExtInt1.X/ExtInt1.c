/* 
 * File:   LEDBlinkMain.c
 * Author: prabr
 *
 * Created on 19 March, 2020, 5:22 PM
 */
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/attribs.h>

#define LED1_DO()       (TRISDCLR=_TRISD_TRISD0_MASK)
#define LED1_ON()       (LATDSET=_LATD_LATD0_MASK)
#define LED1_OFF()      (LATDCLR=_LATD_LATD0_MASK)
#define LED1_TOGGLE()   (LATDINV=_LATD_LATD0_MASK)

#define LED2_DO()       (TRISDCLR=_TRISD_TRISD1_MASK)
#define LED2_ON()       (LATDSET=_LATD_LATD1_MASK)
#define LED2_OFF()      (LATDCLR=_LATD_LATD1_MASK)
#define LED2_TOGGLE()   (LATDINV=_LATD_LATD1_MASK)

#define LED3_DO()       (TRISDCLR=_TRISD_TRISD2_MASK)
#define LED3_ON()       (LATDSET=_LATD_LATD2_MASK)
#define LED3_OFF()      (LATDCLR=_LATD_LATD2_MASK)
#define LED3_TOGGLE()   (LATDINV=_LATD_LATD2_MASK)

#define LED4_DO()       (TRISGCLR=_TRISG_TRISG15_MASK)
#define LED4_ON()       (LATGSET=_LATG_LATG15_MASK)
#define LED4_OFF()      (LATGCLR=_LATG_LATG15_MASK)
#define LED4_TOGGLE()   (LATGINV=_LATG_LATG15_MASK)

#define SW1_DI()        (TRISDSET=_TRISD_TRISD13_MASK)
#define SW1_PRESSED()   (!(PORTD&(1<<_TRISD_TRISD13_POSITION)))

#define SW3_DI()        (TRISESET=_TRISE_TRISE8_MASK)
#define SW3_PRESSED()   (!(PORTE&(1<<_TRISE_TRISE8_POSITION)))
/*Function to produce delay
 * parameter: uint16_t ms: delay in msec
 * return: void
 */
void delay(uint16_t ms)
{
    uint16_t i=0,j=0;
    for(i=0; i<=ms;i++)
        for(j=0;j<=8888;j++);
}
/* Initialize Interrupt 1 
 * parameter: void
 * return: void
 */
void Int1_init(void)
{
    //INT1 initialization
    INTCONSET=_INTCON_MVEC_MASK | _INTCON_INT1EP_MASK; // Multi vector mode, Rising edge
    IFS0CLR=_IFS0_INT1IF_MASK; // clear INT1 flag
    IPC1bits.INT1IP=0x07; // Group priority 7
    IPC1bits.INT1IS=0x03; // Subpriority 3
    IEC0SET=_IEC0_INT1IE_MASK; // Enable INT1    
}

/*
 * This program blinks LED1 and LED2
 * using Switches SW1 and SW3
 * PIC32MX795F512L
 */
volatile uint8_t SW3_status=0;
int main(int argc, char** argv) 
{
    SW1_DI(); //RD13-SW1 as input
    SW3_DI(); //RE8- SW3 as input
    LED1_DO(); LED2_DO(); LED3_DO(); LED4_DO();
    LED1_OFF(); LED2_ON(); LED3_ON(); LED4_OFF();  
    
    Int1_init();// Initilaizes INT1
    __builtin_enable_interrupts();//Enable global Interrupt
    
    while(1)
    {
        if(SW1_PRESSED()) // if SW1 is pressed
        {
            LED1_TOGGLE();
        }
        else // switch not pressed
        {
            LED2_TOGGLE();
        }
        
        if(SW3_status) 
        {
            LED3_TOGGLE();
        }
        else
        {
            LED4_TOGGLE();
        }
    
        delay(1000); // 1sec delay
    }
    return (EXIT_SUCCESS);
}

//ISR
void __ISR(_EXTERNAL_1_VECTOR, IPL7SOFT) ExtInt1_isr(void)
{
    IFS0CLR=_IFS0_INT1IF_MASK; //clear INT1 flag
    //LED3_TOGGLE();
    SW3_status=~SW3_status;
    delay(100);    
}

