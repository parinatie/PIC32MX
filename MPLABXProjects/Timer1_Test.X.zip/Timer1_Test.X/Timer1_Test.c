/* 
 * File:   LEDBlinkMain.c
 * Author: prabr
 *
 * Created on 19 March, 2020, 5:22 PM
 */
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/attribs.h>
#include "lcd_library.h"
#include "PPLib.h"
/*
 * This program blinks LED1 and LED2
 * using Switches SW1 and SW3
 * PIC32MX795F512L
 */
//volatile uint8_t SW1_status=0, SW2_status=0,SW3_status=0, SW4_status=0;
int main(int argc, char** argv) 
{
    //uint8_t i=0;
    SW1_DI(); //RD13-SW1 as input
    SW3_DI(); //RE8- SW3 as input
    LED1_DO(); LED2_DO(); LED3_DO(); LED4_DO();
    LED1_OFF(); LED2_ON(); LED3_ON(); LED4_OFF();  
    
    Timer1_Init();
    __builtin_enable_interrupts();//Enable global Interrupt
    
    lcd_init();
    clear_display();
    lcd_display("   Parinatie    PIC32 Dev. Board");
    while(1)
    {
        LED4_TOGGLE();
        delay(500);        
    }
    return (EXIT_SUCCESS);
}

//ISR
void __ISR(_TIMER_1_VECTOR, IPL7SOFT) Timer1_isr(void)
{
    static uint8_t count=0;    
    count++;
    if(count==5)
    {
        LED1_TOGGLE();
        count=0;
    }
    IFS0CLR=_IFS0_T1IF_MASK; //clear flag
   
}

