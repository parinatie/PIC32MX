/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef PPLIB_H    /* Guard against multiple inclusion */
#define PPLIB_H


/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */


/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


    /* ************************************************************************** */
    /* ************************************************************************** */
    /* Section: Constants                                                         */
    /* ************************************************************************** */
    /* ************************************************************************** */

#define LED1_DO()       (TRISDCLR=_TRISD_TRISD0_MASK)
#define LED1_ON()       (LATDSET=_LATD_LATD0_MASK)
#define LED1_OFF()      (LATDCLR=_LATD_LATD0_MASK)
#define LED1_TOGGLE()   (LATDINV=_LATD_LATD0_MASK)

#define LED2_DO()       (TRISDCLR=_TRISD_TRISD1_MASK)
#define LED2_ON()       (LATDSET=_LATD_LATD1_MASK)
#define LED2_OFF()      (LATDCLR=_LATD_LATD1_MASK)
#define LED2_TOGGLE()   (LATDINV=_LATD_LATD1_MASK)

#define LED3_DO()       (TRISDCLR=_TRISD_TRISD2_MASK)
#define LED3_ON()       (LATDSET=_LATD_LATD2_MASK)
#define LED3_OFF()      (LATDCLR=_LATD_LATD2_MASK)
#define LED3_TOGGLE()   (LATDINV=_LATD_LATD2_MASK)

#define LED4_DO()       (TRISGCLR=_TRISG_TRISG15_MASK)
#define LED4_ON()       (LATGSET=_LATG_LATG15_MASK)
#define LED4_OFF()      (LATGCLR=_LATG_LATG15_MASK)
#define LED4_TOGGLE()   (LATGINV=_LATG_LATG15_MASK)

#define SW1_DI()        (TRISDSET=_TRISD_TRISD13_MASK)
#define SW1_PRESSED()   (!(PORTD&(1<<_TRISD_TRISD13_POSITION)))

#define SW2_DI()        (TRISBSET=_TRISB_TRISB0_MASK)
#define SW2_PRESSED()   (!(PORTB&(1<<_TRISB_TRISB0_POSITION)))
    
#define SW3_DI()        (TRISESET=_TRISE_TRISE8_MASK)
#define SW3_PRESSED()   (!(PORTE&(1<<_TRISE_TRISE8_POSITION)))
    
#define SW4_DI()        (TRISBSET=_TRISB_TRISB1_MASK)
#define SW4_PRESSED()   (!(PORTB&(1<<_TRISB_TRISB1_POSITION)))


    // *****************************************************************************
    // *****************************************************************************
    // Section: Data Types
    // *****************************************************************************
    // *****************************************************************************

   

    // *****************************************************************************
    // *****************************************************************************
    // Section: Interface Functions
    // *****************************************************************************
    // *****************************************************************************

/*Function to produce delay
 * parameter: uint16_t ms: delay in msec
 * return: void
 */
void delay(uint16_t ms);

/* Initialize Interrupt 1 
 * parameter: void
 * return: void
 */
void Int1_init(void);

/* Function- Initializes CN19 with internal pull-up disabled
 * parameter: void
 * return: void
 */
void CN19_Init(void);

/* Function- Initializes CN2 with internal pull-up enabled
 * parameter: void
 * return: void
 */
void CN2_Init(void);
/* Function- Initializes CN3 with internal pull-up enabled
 * parameter: void
 * return: void
 */
void CN3_Init(void);

/*Function Timer 1 Initialization
 * parameter: void
 * return: void 
 */
void Timer1_Init(void);

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
