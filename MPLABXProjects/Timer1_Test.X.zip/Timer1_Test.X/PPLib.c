#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/attribs.h>
/*Function to produce delay
 * parameter: uint16_t ms: delay in msec
 * return: void
 */
void delay(uint16_t ms)
{
    uint16_t i=0,j=0;
    for(i=0; i<=ms;i++)
        for(j=0;j<=8888;j++);
}

/* Initialize Interrupt 1 
 * parameter: void
 * return: void
 */
void Int1_init(void)
{
    //INT1 initialization
    INTCONSET=_INTCON_MVEC_MASK | _INTCON_INT1EP_MASK; // Multi vector mode, Rising edge
    IFS0CLR=_IFS0_INT1IF_MASK; // clear INT1 flag
    IPC1bits.INT1IP=0x07; // Group priority 7
    IPC1bits.INT1IS=0x03; // Subpriority 3
    IEC0SET=_IEC0_INT1IE_MASK; // Enable INT1    
} 

/* Function- Initializes CN19 with internal pull-up disabled
 * parameter: void
 * return: void
 */
void CN19_Init(void)
{
    //CN initialization - RD13- CN19
    CNCONSET=_CNCON_ON_MASK; // CN Module- ON
    CNENSET=_CNEN_CNEN19_MASK; // Enable CN on CN19
    CNPUECLR= _CNPUE_CNPUE19_MASK; // Disable Internal pullup on CN19- External pullup available
    PORTD; // Clear mismatch condition on RD13
    IFS1CLR=_IFS1_CNIF_MASK; // Clear CN Interrupt flag    
    IPC6bits.CNIP=0x07;// Group priority 7
    IPC6bits.CNIS=0x02; //Sub priority 2
    IEC1SET= _IEC1_CNIE_MASK; // Enable CN Interrupt
}

/* Function- Initializes CN2 with internal pull-up enabled
 * parameter: void
 * return: void
 */
void CN2_Init(void)
{
    //CN initialization - RB0- CN2
    TRISBSET=_TRISB_TRISB0_MASK; // RB0 input
    AD1PCFGSET=_AD1PCFG_PCFG0_MASK; // RB0 is digital
    CNCONSET=_CNCON_ON_MASK; // CN Module- ON
    CNENSET=_CNEN_CNEN2_MASK; // Enable CN on CN2
    CNPUESET= _CNPUE_CNPUE2_MASK; // Enable Internal pullup on CN2
    PORTB; // Clear mismatch condition on RB0
    IFS1CLR=_IFS1_CNIF_MASK; // Clear CN Interrupt flag    
    IPC6bits.CNIP=0x07;// Group priority 7
    IPC6bits.CNIS=0x02; //Sub priority 2
    IEC1SET= _IEC1_CNIE_MASK; // Enable CN Interrupt
}

/* Function- Initializes CN3 with internal pull-up enabled
 * parameter: void
 * return: void
 */
void CN3_Init(void)
{
    //CN initialization - RB1- CN3
    TRISBSET=_TRISB_TRISB1_MASK; // RB1 input
    AD1PCFGSET=_AD1PCFG_PCFG1_MASK; // RB1 is digital
    CNCONSET=_CNCON_ON_MASK; // CN Module- ON
    CNENSET=_CNEN_CNEN3_MASK; // Enable CN on CN3
    CNPUESET= _CNPUE_CNPUE3_MASK; // Enable Internal pullup on CN3
    PORTB; // Clear mismatch condition on RB1
    IFS1CLR=_IFS1_CNIF_MASK; // Clear CN Interrupt flag    
    IPC6bits.CNIP=0x07;// Group priority 7
    IPC6bits.CNIS=0x02; //Sub priority 2
    IEC1SET= _IEC1_CNIE_MASK; // Enable CN Interrupt
}

/*Function Timer 1 Initialization
 * parameter: void
 * return: void 
 */
void Timer1_Init(void)
{
    //Timer1 Initialization
    T1CONCLR=_T1CON_TCS_MASK | _T1CON_TGATE_MASK; // Internal clock, Gate accummulation off
    T1CONbits.TCKPS=3; // 0- 1:1 Prescaler,1- 1:8 Prescaler, 2- 1:64 Prescaler, 3- 1:256 Prescaler
    TMR1=0;
    PR1=62500; // 0.1 sec at 1:256, maximum for 16-bit timer, 2^16 -1
    
    //Timer 1 Interrupt
    INTCONSET=_INTCON_MVEC_MASK;
    IFS0CLR=_IFS0_T1IF_MASK; // Clear Timer1 interrupt flag
    IPC1bits.T1IP=7;
    IPC1bits.T1IS=1;    
    IEC0SET=_IEC0_T1IE_MASK; // Enable Timer1 Interrupt
    T1CONSET=_T1CON_TON_MASK; // Timer1 ON
}
